//Swift is a (blank blank). The language is made by Apple to build applications for the ap store. In this intro I want to explain data types and develop a small foundation to build on



print("Hello, hello!")
print()
//The Variables, Data Types & Comments

var day: String = "Monday"
var numberOfMinutes: Int = 10
var pi: Double = 3.14
var isCorrect: Bool = true



//Using Print
print(day)
print(numberOfMinutes)
print(pi)
print(isCorrect)
print()

print("\(day), for \(numberOfMinutes) minutes we learned that 'pi = \(pi)' is \(isCorrect)!")


